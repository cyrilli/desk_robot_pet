# Tobi 桌宠课程包

| 文件夹 | 内容 |
| --- | --- |
| `hardware/` | `bom.csv` 是采购清单，`wiring.svg` 是 USB 供电接线图。 |
| `firmware/` | `original/original.ino` 是课堂用的原版程序；`hardware_check/hardware_check.ino` 用来查屏幕地址和触摸信号。 |
| `3d-models/` | 作者提供的三份外壳 STL。 |
| `simulation/` | `tobi-original.vlx` 可导入 Velxio，在电脑上试原版。 |

有硬件时，先断电按图接线。在 Arduino IDE 选择 **ESP32C3 Dev Module**，启用 **USB CDC On Boot**。先运行自检程序，再打开 `original.ino`。原版需要 Adafruit GFX、Adafruit SSD1306 和 Adafruit BusIO 三个库。

改程序时，先复制 `firmware/original/`，让副本文件夹与里面的 `.ino` 文件同名。名牌源码、改造示例和操作步骤可在课程网站相应章节下载。

原项目：[Tobi ESP32 Robot](https://github.com/samrobotech/Tobi-esp32-robot/tree/428afbe3785887b91920e57dab453c5c4b815f24)，作者 Sam Zare，许可见 `LICENSE`。课程固件用两道弧线画出单击后的笑眼，并提供屏幕地址、接线说明、触摸输入下拉和串口日志。
