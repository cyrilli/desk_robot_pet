#include <Wire.h>
void setup() {
#if ARDUINO_USB_CDC_ON_BOOT
  Serial.begin(115200);
#else
  Serial.begin(115200, SERIAL_8N1, 3, 4);
#endif
  pinMode(10, INPUT_PULLDOWN);
  Wire.begin(20,21);
}
void loop() {
  static unsigned long scanned = 0;
  static bool first = true;
  if (first || millis()-scanned >= 5000) {
    first=false;scanned=millis();
    for (int addr=1;addr<127;addr++) {
      Wire.beginTransmission(addr);
      if (Wire.endTransmission()==0) Serial.printf("I2C device 0x%02X\n",addr);
    }
  }
  static int previous=-1;
  int current=digitalRead(10);
  if(current!=previous){Serial.printf("TOUCH=%d\n",current);previous=current;}
  delay(10);
}
