#include <esp_arduino_version.h>
const int SERVO_PIN = 5;
const int TOUCH_PIN = 10;
const int CHANNEL = 0;
void writeAngle(int degrees) {
  degrees=constrain(degrees,70,110); // Conservative initial mechanical range.
  unsigned long pulse=1500L+(degrees-90)*500L/90;
  unsigned long duty=pulse*16383UL/20000UL;
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(SERVO_PIN,duty);
#else
  ledcWrite(CHANNEL,duty);
#endif
}
void setup(){
  pinMode(TOUCH_PIN,INPUT_PULLDOWN);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(SERVO_PIN,50,14);
#else
  ledcSetup(CHANNEL,50,14);ledcAttachPin(SERVO_PIN,CHANNEL);
#endif
  writeAngle(90);
}
void loop(){
  static int phase=0;
  static bool prev=false;
  static unsigned long started=0;
  bool touch=digitalRead(TOUCH_PIN);
  if(touch&&!prev&&phase==0){phase=1;started=millis();writeAngle(75);}
  prev=touch;
  if(phase==1&&millis()-started>=400){phase=2;started=millis();writeAngle(105);}
  if(phase==2&&millis()-started>=400){phase=3;started=millis();writeAngle(90);}
  if(phase==3&&millis()-started>=400)phase=0;
}
