"""用本机 Velxio 编译单个 Arduino 草图，供 Tobi 三维仿真载入。"""
import argparse
import base64
import json
from pathlib import Path
import sys
import tempfile
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener


API = 'http://127.0.0.1:3080/api/compile/'


def compile_sketch(source):
    request = Request(API, data=json.dumps({
        'code': source,
        'board_fqbn': 'esp32:esp32:esp32c3',
        'board_kind': 'esp32-c3-devkit',
        'libraries': ['Adafruit SSD1306', 'Adafruit GFX Library', 'Adafruit BusIO'],
    }).encode(), headers={'Content-Type': 'application/json'})
    try:
        with build_opener(ProxyHandler({})).open(request, timeout=900) as response:
            result = json.load(response)
    except HTTPError as error:
        raise ValueError(f'本机编译服务返回 HTTP {error.code}。请检查 Velxio 是否已启动。') from error
    except (TimeoutError, URLError) as error:
        raise ValueError(f'无法完成本机编译请求。请确认能打开 http://127.0.0.1:3080/editor/ 。\n{error}') from error
    except (UnicodeError, json.JSONDecodeError) as error:
        raise ValueError('本机编译服务未返回有效的 JSON 结果。') from error

    if not isinstance(result, dict):
        raise ValueError('本机编译服务返回的结果格式不正确。')
    if result.get('success') is not True:
        details = '\n'.join(str(result[key]) for key in ('error', 'stderr') if result.get(key))
        errors = [line for line in details.splitlines()
                  if 'error:' in line.lower() or 'undefined reference' in line.lower()]
        report = '\n'.join(dict.fromkeys(errors)) or details
        raise ValueError('编译失败。请按下面的信息检查草图。\n' + (report[-2500:] or '服务未返回诊断信息。'))
    try:
        firmware = base64.b64decode(result['binary_content'], validate=True)
    except (KeyError, ValueError, TypeError) as error:
        raise ValueError('编译结果中的固件数据缺失或损坏。') from error
    # The image header identifies ESP32-C3 by chip ID 5 at bytes 12–13.
    if len(firmware) < 24 or firmware[0] != 0xe9 or int.from_bytes(firmware[12:14], 'little') != 5:
        raise ValueError('返回的文件缺少有效的 ESP32-C3 固件头。')
    return firmware


def main():
    parser = argparse.ArgumentParser(description='把单个 .ino 编译为同目录、同名的 ESP32-C3 .bin 文件。')
    parser.add_argument('sketch', type=Path, metavar='草图.ino', help='修改后的 Arduino 草图路径')
    source = parser.parse_args().sketch.expanduser()
    if source.suffix.lower() != '.ino':
        parser.error('请选择一个 .ino 文件。')
    output = source.with_suffix('.bin')
    try:
        text = source.read_text(encoding='utf-8-sig')
        print(f'正在使用本机 Velxio 编译 {source.name} …', flush=True)
        firmware = compile_sketch(text)
        # Only replace an earlier build once the new file has been written in full.
        with tempfile.TemporaryDirectory(dir=output.parent) as staging:
            temp = Path(staging) / output.name
            temp.write_bytes(firmware)
            temp.replace(output)
    except (OSError, ValueError) as error:
        print(f'未生成新的固件。{error}', file=sys.stderr)
        return 1
    print(f'已生成 {output.absolute()}（{len(firmware):,} 字节）。')
    return 0


if __name__ == '__main__':
    sys.exit(main())
